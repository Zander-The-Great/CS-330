#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h> // Camera class

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
const char* const WINDOW_TITLE = "Final Project"; // Macro for window title

// Variables for window width and height
const int WINDOW_WIDTH = 1600;
const int WINDOW_HEIGHT = 1080;

// Stores the GL data relative to a given mesh
struct GLMesh
{
    GLuint vao;         // Handle for the vertex array object
    GLuint vbo;         // Handle for the vertex buffer object
    GLuint nVertices;    // Number of indices of the mesh
};

// Main GLFW window
GLFWwindow* gWindow = nullptr;
// Triangle mesh data
GLMesh gMesh;
// Texture
GLuint gTextureId;

//GLint gTexWrapMode = GL_LINEAR;

// Shader programs
GLuint gCubeProgramId;
GLuint gLampProgramId;

// Texture id
GLuint gTextureTable;
GLuint gTextureChairs;
GLuint gTextureFloor;
GLuint gTextureWall;
GLuint gTextureHoney;
GLuint gTextureOrange;
GLuint gTextureWindow;
GLuint gTextureCeiling;
GLuint gTextureAdam;
GLuint gTextureStarry;
GLuint gTexture83;
GLuint gTextureZTG;
GLuint gTextureFlower;


// Shader program
GLuint gProgramId;
GLuint gTableProgramId;
GLuint gChairsProgramId;
GLuint gFloorProgramId;
GLuint gWallProgramId;
GLuint gCerealProgramId;
GLuint gOrangeProgramId;
GLuint gWindowProgramId;
GLuint gAdamProgramId;
GLuint gStarryProgramId;
GLuint g83ProgramId;
GLuint gZTGProgramId;
GLuint gFlowerProgramId;



GLuint gCeilingProgramId;
glm::vec2 gUVScale(1.0f, 1.0f);
GLint gTexWrapMode = GL_LINEAR;

// camera
Camera gCamera(glm::vec3(0.0f, 1.0f, 10.0f));
float gLastX = WINDOW_WIDTH / 2.0f;
float gLastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;

// timing
float gDeltaTime = 0.0f; // time between current frame and last frame
float gLastFrame = 0.0f;

bool ortho = false;

// Subject position and scale
glm::vec3 gCubePosition(0.0f, 0.0f, 0.0f);
glm::vec3 gCubeScale(2.0f);

// Cube and light color
//m::vec3 gObjectColor(0.6f, 0.5f, 0.75f);
glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
glm::vec3 gLightColor(0.99f, 0.99f, 0.99f);

// Light position and scale
glm::vec3 gLightPosition(0.0f, 1.0f, -0.0f);
glm::vec3 gLightScale(0.5f);

// Lamp animation
bool gIsLampOrbiting = false;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char*[], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh &mesh);
void UDestroyMesh(GLMesh &mesh);
bool UCreateTexture(const char* filename, GLuint &textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId);
void UDestroyShaderProgram(GLuint programId);



/* Cube Vertex Shader Source Code*/
const GLchar * cubeVertexShaderSource = GLSL(440,

    layout (location = 0) in vec3 position; // VAP position 0 for vertex position data
    layout (location = 1) in vec3 normal; // VAP position 1 for normals
    layout (location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection; 

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

        vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
        vertexTextureCoordinate = textureCoordinate;
    }
);


/* Cube Fragment Shader Source Code*/
const GLchar * cubeFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
    in vec3 vertexFragmentPos; // For incoming fragment position
    in vec2 vertexTextureCoordinate;

    out vec4 fragmentColor; // For outgoing cube color to the GPU

    // Uniform / Global variables for object color, light color, light position, and camera/view position
    uniform vec3 objectColor;
    uniform vec3 lightColor;
    uniform vec3 lightPos;
    uniform vec3 viewPosition;
    uniform sampler2D uTexture; // Useful when working with multiple textures
    uniform vec2 uvScale;

    void main()
    {
        /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

        //Calculate Ambient lighting*/
        float ambientStrength = .15f; // Set ambient or global lighting strength
        vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

        //Calculate Diffuse lighting*/
        vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
        vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
        float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
        vec3 diffuse = impact * lightColor; // Generate diffuse light color

        //Calculate Specular lighting*/
        float specularIntensity = 1.0f; // Set specular light strength
        float highlightSize = 16.0f; // Set specular highlight size
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
        vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
        //Calculate specular component
        float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
        vec3 specular = specularIntensity * specularComponent * lightColor;

        // Texture holds the color to be used for all three components
        vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

        // Calculate phong result
        vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

        fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
    }
);


/* Lamp Shader Source Code*/
const GLchar * lampVertexShaderSource = GLSL(440,

    layout (location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);


/* Fragment Shader Source Code*/
const GLchar * lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

    void main()
    {
        fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
    }
);


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char *image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCubeProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Create the shader program
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gTableProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gFloorProgramId))
        return EXIT_FAILURE;
   if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gWallProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCerealProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gOrangeProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gWindowProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCeilingProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, g83ProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gStarryProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gZTGProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gFlowerProgramId))
        return EXIT_FAILURE;

     //Load texture
    const char * texFilename = "../../resources/textures/wood.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCubeProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCubeProgramId, "uTexture"), 0);

    // Load texture
    const char* texTable = "../../resources/textures/wood.jpg";
    if (!UCreateTexture(texTable, gTextureTable))
    {
        cout << "Failed to load texture " << texTable << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gTableProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureTable, "uTexture"), 0);

    const char* texFloor = "../../resources/textures/Tile.jpg";
    if (!UCreateTexture(texFloor, gTextureFloor))
    {
        cout << "Failed to load texture " << texFloor << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gFloorProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureFloor, "uTexture"), 0);


    const char* texCereal = "../../resources/textures/honey.jpg";
    if (!UCreateTexture(texCereal, gTextureHoney))
    {
        cout << "Failed to load texture " << texCereal << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCerealProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureHoney, "uTexture"), 0);

    const char* texWall = "../../resources/textures/Grey.jpg";
    if (!UCreateTexture(texWall, gTextureWall))
    {
        cout << "Failed to load texture " << texWall << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gWallProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureWall, "uTexture"), 0);


    // Load texture
    const char* texOrange = "../../resources/textures/Orange.jpg";
    if (!UCreateTexture(texOrange, gTextureOrange))
    {
        cout << "Failed to load texture " << texOrange << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gOrangeProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureOrange, "uTexture"), 0);

    const char* texWindow = "../../resources/textures/Window1.png";
    if (!UCreateTexture(texWindow, gTextureWindow))
    {
        cout << "Failed to load texture " << texWindow << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gWindowProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureWindow, "uTexture"), 0);

    const char* texCeiling = "../../resources/textures/Ceiling.jpg";
    if (!UCreateTexture(texCeiling, gTextureCeiling))
    {
        cout << "Failed to load texture " << texCeiling << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCeilingProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureCeiling, "uTexture"), 0);

    const char* tex83 = "../../resources/textures/83.jpg";
    if (!UCreateTexture(tex83, gTexture83))
    {
        cout << "Failed to load texture " << tex83 << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(g83ProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTexture83, "uTexture"), 0);

    const char* texStarry = "../../resources/textures/Starry.jpg";
    if (!UCreateTexture(texStarry, gTextureStarry))
    {
        cout << "Failed to load texture " << texStarry << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gStarryProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gTextureStarry, "uTexture"), 0);


    //const char* texZTG = "../../resources/textures/ZTG.jpg";
    //if (!UCreateTexture(texZTG, gTextureZTG))
    //{
    //    cout << "Failed to load texture " << texZTG << endl;
    //    return EXIT_FAILURE;
    //}
    //// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    //glUseProgram(gZTGProgramId);
    //// We set the texture as texture unit 0
    //glUniform1i(glGetUniformLocation(gTextureZTG, "uTexture"), 0);

    //const char* texFlower = "../../resources/textures/Flower.jpg";
    //if (!UCreateTexture(texFlower, gTextureFlower))
    //{
    //    cout << "Failed to load texture " << texFilename << endl;
    //    return EXIT_FAILURE;
    //}
    //// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    //glUseProgram(gFlowerProgramId);
    //// We set the texture as texture unit 0
    //glUniform1i(glGetUniformLocation(gTextureFlower, "uTexture"), 0);




    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureId);

    // Release shader programs
    UDestroyShaderProgram(gCubeProgramId);
    UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    //setup P for perspective/ortho view
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        gCamera.WorldUp = glm::vec3(0.0f, -1.0f, -1.0f);
        ortho = true;
    }
    else
    {
        gCamera.WorldUp = glm::vec3(0.0f, 1.0f, 0.0f);
        ortho = false;
    }

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

   if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS && gTexWrapMode != GL_REPEAT)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_REPEAT;

        cout << "Current Texture Wrapping Mode: REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS && gTexWrapMode != GL_MIRRORED_REPEAT)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_MIRRORED_REPEAT;

        cout << "Current Texture Wrapping Mode: MIRRORED REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_EDGE)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_EDGE;

        cout << "Current Texture Wrapping Mode: CLAMP TO EDGE" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_BORDER)
    {
        float color[] = {1.0f, 0.0f, 1.0f, 1.0f};
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);

        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_BORDER;

        cout << "Current Texture Wrapping Mode: CLAMP TO BORDER" << endl;
    }

    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
    {
        gUVScale += 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
    {
        gUVScale -= 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }

    // Pause and resume lamp orbiting
    static bool isLKeyDown = false;
    if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS && !gIsLampOrbiting)
        gIsLampOrbiting = true;
    else if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS && gIsLampOrbiting)
        gIsLampOrbiting = false;

}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
        case GLFW_MOUSE_BUTTON_LEFT:
        {
            if (action == GLFW_PRESS)
                cout << "Left mouse button pressed" << endl;
            else
                cout << "Left mouse button released" << endl;
        }
        break;

        case GLFW_MOUSE_BUTTON_MIDDLE:
        {
            if (action == GLFW_PRESS)
                cout << "Middle mouse button pressed" << endl;
            else
                cout << "Middle mouse button released" << endl;
        }
        break;

        case GLFW_MOUSE_BUTTON_RIGHT:
        {
            if (action == GLFW_PRESS)
                cout << "Right mouse button pressed" << endl;
            else
                cout << "Right mouse button released" << endl;
        }
        break;

        default:
            cout << "Unhandled mouse button event" << endl;
            break;
    }
}


// Functioned called to render a frame
void URender()
{
    // Lamp orbits around the origin
    const float angularVelocity = glm::radians(45.0f);
    if (gIsLampOrbiting)
    {
        glm::vec4 newPosition = glm::rotate(angularVelocity * gDeltaTime, glm::vec3(0.0f, 1.0f, 0.0f)) * glm::vec4(gLightPosition, 1.0f);
        gLightPosition.x = newPosition.x;
        gLightPosition.y = newPosition.y;
        gLightPosition.z = newPosition.z;
    }

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);
    
    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Activate the cube VAO (used by cube and lamp)
    glBindVertexArray(gMesh.vao);

    //------table-------

   //Table top
    glUseProgram(gTableProgramId);
   // 1. Scales the object by 2
    glm::mat4 scale = glm::scale(glm::vec3(4.0f, .15f, 4.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    // Set the shader to be used
    

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gTableProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gTableProgramId, "view");
    GLint projLoc = glGetUniformLocation(gTableProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(gTableProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gTableProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gTableProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gTableProgramId, "viewPosition");

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gTableProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTable);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);



    //Table Leg #1
    // 1. Scales the object by 2
    glm::mat4 scale1 = glm::scale(glm::vec3(0.25f, 2.0f, 0.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation1 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation1 = glm::translate(glm::vec3(-1.85f, -1.0f, -1.85f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model1 = translation1 * rotation1 * scale1;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model1));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle

    //Table Leg #2 
    // 1. Scales the object by 2
    glm::mat4 scale2 = glm::scale(glm::vec3(0.25f, 2.0f, 0.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation2 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation2 = glm::translate(glm::vec3(1.85f, -1.0f, 1.85f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model2 = translation2 * rotation2 * scale2;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model2));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle

    //Table Leg #3
     // 1. Scales the object by 2
    glm::mat4 scale3 = glm::scale(glm::vec3(0.25f, 2.0f, 0.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation3 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation3 = glm::translate(glm::vec3(-1.85f, -1.0f, 1.85f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model3 = translation3 * rotation3 * scale3;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model3));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle

    //Table Leg #4
     // 1. Scales the object by 2
    glm::mat4 scale4 = glm::scale(glm::vec3(0.25f, 2.0f, 0.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation4 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation4 = glm::translate(glm::vec3(1.85f, -1.0f, -1.85f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model4 = translation4 * rotation4 * scale4;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model4));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    //------Chairs----------
   //Chair1 -- Back
       // Set the shader to be used
 
    // 1. Scales the object by 2
    glm::mat4 scale6 = glm::scale(glm::vec3(0.10f, 1.5f, 1.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation6 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation6 = glm::translate(glm::vec3(-3.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model6 = translation6 * rotation6 * scale6;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model6));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);


    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    //Chair 1 Seat

         // 1. Scales the object by 2
    glm::mat4 scale7 = glm::scale(glm::vec3(1.0f, 0.1f, 1.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation7 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation7 = glm::translate(glm::vec3(-2.55f, -0.8f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model7 = translation7 * rotation7 * scale7;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model7));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    //Chair 1 leg1

         // 1. Scales the object by 2
    glm::mat4 scale8 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation8 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation8 = glm::translate(glm::vec3(-2.98f, -1.35f, -.55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model8 = translation8 * rotation8 * scale8;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model8));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//Chair 1 leg 2

     // 1. Scales the object by 2
    glm::mat4 scale9 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation9 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation9 = glm::translate(glm::vec3(-2.125f, -1.35f, -.55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model9 = translation9 * rotation9 * scale9;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model9));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//Chair 1 leg 3

     // 1. Scales the object by 2
    glm::mat4 scale10 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation10 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation10 = glm::translate(glm::vec3(-2.125f, -1.35f, 0.55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model10 = translation10 * rotation10 * scale10;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model10));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//Chair 1 leg 4

     // 1. Scales the object by 2
    glm::mat4 scale11 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation11 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation11 = glm::translate(glm::vec3(-2.98f, -1.35f, .55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model11 = translation11 * rotation11 * scale11;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model11));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    //Chair 2 Back

         // 1. Scales the object by 2
    glm::mat4 scale12 = glm::scale(glm::vec3(0.10f, 1.5f, 1.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation12 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation12 = glm::translate(glm::vec3(3.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model12 = translation12 * rotation12 * scale12;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model12));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//Chair 2 Seat

     // 1. Scales the object by 2
    glm::mat4 scale13 = glm::scale(glm::vec3(1.0f, 0.1f, 1.25f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation13 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation13 = glm::translate(glm::vec3(2.55f, -0.8f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model13 = translation13 * rotation13 * scale13;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model13));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//Chair 2 leg 1

     // 1. Scales the object by 2
    glm::mat4 scale14 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation14 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation14 = glm::translate(glm::vec3(2.98f, -1.35f, .55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model14 = translation14 * rotation14 * scale14;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model14));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//chair 2 leg 2

     // 1. Scales the object by 2
    glm::mat4 scale15 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation15 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation15 = glm::translate(glm::vec3(2.125f, -1.35f, .55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model15 = translation15 * rotation15 * scale15;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model15));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//chair 2 leg 3

     // 1. Scales the object by 2
    glm::mat4 scale16 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation16 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation16 = glm::translate(glm::vec3(2.125f, -1.35f, -.55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model16 = translation16 * rotation16 * scale16;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model16));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


//chair 2 leg 4

     // 1. Scales the object by 2
    glm::mat4 scale17 = glm::scale(glm::vec3(0.15f, 1.0f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation17 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation17 = glm::translate(glm::vec3(2.98f, -1.35f, -.55f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model17 = translation17 * rotation17 * scale17;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model17));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle

    //-----Cereal Box-----

         // 1. Scales the object by 2
    glm::mat4 scale18 = glm::scale(glm::vec3(0.5f, 0.8f, 0.15f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation18 = glm::rotate(26.0f, glm::vec3(0.0, -1.0f, 0.0f));
    // 3. Place object at the origin
    glm::mat4 translation18 = glm::translate(glm::vec3(0.77, 0.48f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model18 = translation18 * rotation18 * scale18;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model18));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureHoney);


    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle




    
     //-----floor-----

    glUseProgram(gTableProgramId);
    // 1. Scales the object by 2
    glm::mat4 scale5 = glm::scale(glm::vec3(10.0f, 0.10f, 13.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation5 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation5 = glm::translate(glm::vec3(0.0f, -2.0f, 4.5f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model5 = translation5 * rotation5 * scale5;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gFloorProgramId, "model");
    viewLoc = glGetUniformLocation(gFloorProgramId, "view");
    projLoc = glGetUniformLocation(gFloorProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model5));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureFloor);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle

    // Wall 1 - Right

    // 1. Scales the object by 2
    glm::mat4 scale19 = glm::scale(glm::vec3(0.10f, 7.0f, 13.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation19 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation19 = glm::translate(glm::vec3(5.0f, 1.5f, 4.5f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model19 = translation19 * rotation19 * scale19;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    
    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gWallProgramId, "model");
    viewLoc = glGetUniformLocation(gWallProgramId, "view");
    projLoc = glGetUniformLocation(gWallProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model19));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureWall);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle 


    //Wall 2 - left
    // 1. Scales the object by 2
    glm::mat4 scale20 = glm::scale(glm::vec3(0.10f, 7.0f, 13.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation20 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation20 = glm::translate(glm::vec3(-5.0f, 1.5f, 4.5f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model20 = translation20 * rotation20 * scale20;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gWallProgramId, "model");
    viewLoc = glGetUniformLocation(gWallProgramId, "view");
    projLoc = glGetUniformLocation(gWallProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model20));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureWall);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle

    //Wall 3 - Back

     // 1. Scales the object by 2
    glm::mat4 scale21 = glm::scale(glm::vec3(10.0f, 7.0f, 0.10f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation21 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation21 = glm::translate(glm::vec3(0.0f, 1.5f, -2.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model21 = translation21 * rotation21 * scale21;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gWallProgramId, "model");
    viewLoc = glGetUniformLocation(gWallProgramId, "view");
    projLoc = glGetUniformLocation(gWallProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model21));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureWall);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    //Ceiling
     // 1. Scales the object by 2
    glm::mat4 scale23 = glm::scale(glm::vec3(10.0f, 0.10f, 13.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation23 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation23 = glm::translate(glm::vec3(0.0f, 5.0f, 4.5f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model23 = translation23 * rotation23 * scale23;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gCeilingProgramId, "model");
    viewLoc = glGetUniformLocation(gCeilingProgramId, "view");
    projLoc = glGetUniformLocation(gCeilingProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model23));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCeiling);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    //Window
     // 1. Scales the object by 2
    glm::mat4 scale22 = glm::scale(glm::vec3(3.0f, 4.0f, 0.010f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation22 = glm::rotate(0.0f, glm::vec3(1.0, 3.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation22 = glm::translate(glm::vec3(0.0f, 2.0f, -1.95f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model22 = translation22 * rotation22 * scale22;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gWindowProgramId, "model");
    viewLoc = glGetUniformLocation(gWindowProgramId, "view");
    projLoc = glGetUniformLocation(gWindowProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model22));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureWindow);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle


    
   

    
     //MARCO Island
     // 1. Scales the object by 2
    glm::mat4 scale26 = glm::scale(glm::vec3(0.1f, 4.0f, 3.0));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation26 = glm::rotate(7.84f, glm::vec3(1.0, 0.0f, 0.0f));
    // 3. Place object at the origin
    glm::mat4 translation26 = glm::translate(glm::vec3(-4.9f, 2.0f, 5.0));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model26 = translation26 * rotation26 * scale26;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(g83ProgramId, "model");
    viewLoc = glGetUniformLocation(g83ProgramId, "view");
    projLoc = glGetUniformLocation(g83ProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model26));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTexture83);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle
    

    //Starry
     // 1. Scales the object by 2
    glm::mat4 scale25 = glm::scale(glm::vec3(0.1f, 4.0f, 3.0));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation25 = glm::rotate(7.84f, glm::vec3(1.0, 0.0f, 0.0f));
    // 3. Place object at the origin
    glm::mat4 translation25 = glm::translate(glm::vec3(4.9f, 2.0f, 5.0));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model25 = translation25 * rotation25 * scale25;

    // Setup views and projections
    if (ortho) {
        GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; // 10% of width
        GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; // 10% of height

        view = gCamera.GetViewMatrix();
        projection = glm::ortho(-oWidth, oWidth, oHeight, -oHeight, 0.1f, 100.0f);
    }
    else {
        view = gCamera.GetViewMatrix();
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gStarryProgramId, "model");
    viewLoc = glGetUniformLocation(gStarryProgramId, "view");
    projLoc = glGetUniformLocation(gStarryProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model25));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureStarry);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices); // Draws the triangle





    //// LAMP: draw lamp
    ////----------------
    //glUseProgram(gLampProgramId);

    ////Transform the smaller cube used as a visual que for the light source
    //model = glm::translate(gLightPosition) * glm::scale(gLightScale);

    //// Reference matrix uniforms from the Lamp Shader program
    //modelLoc = glGetUniformLocation(gLampProgramId, "model");
    //viewLoc = glGetUniformLocation(gLampProgramId, "view");
    //projLoc = glGetUniformLocation(gLampProgramId, "projection");

    //// Pass matrix data to the Lamp Shader program's matrix uniforms
    //glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    //glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    //glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);


    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh &mesh)
{
     // Position and Color data
    GLfloat verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

        //Front Face         //Positive Z Normal
       -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

        //Left Face          //Negative X Normal
       -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
       -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        //Right Face         //Positive X Normal
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        //Bottom Face        //Negative Y Normal
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

        //Top Face           //Positive Y Normal
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride =  sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UDestroyMesh(GLMesh &mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, &mesh.vbo);
}


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint &textureId)
{
    int width, height, channels;
    unsigned char *image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
        	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
        	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
     
        else
        {
        	cout << "Not implemented to handle image with " << channels << " channels" << endl;
        	return false;
        }

		glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
